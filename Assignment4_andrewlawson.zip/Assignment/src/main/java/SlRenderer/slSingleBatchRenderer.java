package SlRenderer;

import csc133.slCamera;
import csc133.Spot;
import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;
import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.glfw.GLFWFramebufferSizeCallback;
import org.lwjgl.glfw.GLFWKeyCallback;
import org.lwjgl.opengl.GL;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL20.*;


public class slSingleBatchRenderer {
    GLFWErrorCallback errorCallback;
    GLFWKeyCallback keyCallback;
    GLFWFramebufferSizeCallback fbCallback;
    int WIN_POS_X = 30, WIN_POX_Y = 90;
    float xmin;
    float ymin;
    float xmax;
    float ymax;
    private static final int OGL_MATRIX_SIZE = 16;
    // call glCreateProgram() here - we have no gl-context here
    int shader_program;
    Matrix4f viewProjMatrix = new Matrix4f();
    FloatBuffer myFloatBuffer = BufferUtils.createFloatBuffer(OGL_MATRIX_SIZE);
    int vpMatLocation = 0, renderColorLocation = 0;
    csc133.slWindow WINDOW = new csc133.slWindow();
    long window;
    public void render() {
        try {
            WINDOW.slWindow(Spot.WIN_WIDTH, Spot.WIN_HEIGHT);
            window = WINDOW.get_oglWindow(Spot.WIN_WIDTH, Spot.WIN_HEIGHT);
            renderLoop();
            WINDOW.Destroy();
            //keyCallback.free();
            //fbCallback.free();
        } finally {
            glfwTerminate();
            glfwSetErrorCallback(null).free();
        }
    }
    void renderLoop() {
        glfwPollEvents();
        initOpenGL();
        renderObjects();
        /* Process window messages in the main thread */
        while (!glfwWindowShouldClose(window)) {
            glfwWaitEvents();
        }
    } // void renderLoop()
    void initOpenGL() {
        GL.createCapabilities();
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_CULL_FACE);
        glViewport(600, -50, Spot.WIN_WIDTH, Spot.WIN_HEIGHT);
        glClearColor(0.0f, 0.0f, 1.0f, 1.0f);
        this.shader_program = glCreateProgram();
        int vs = glCreateShader(GL_VERTEX_SHADER);
        glShaderSource(vs,
                "uniform mat4 viewProjMatrix;" +
                        "void main(void) {" +
                        " gl_Position = viewProjMatrix * gl_Vertex;" +
                        "}");
        glCompileShader(vs);
        glAttachShader(shader_program, vs);
        int fs = glCreateShader(GL_FRAGMENT_SHADER);
        glShaderSource(fs,
                "uniform vec3 color;" +
                        "void main(void) {" +
                        " gl_FragColor = vec4(0.7f, 0.5f, 0.1f, 1.0f);" +
                        "}");
        glCompileShader(fs);
        glAttachShader(shader_program, fs);
        glLinkProgram(shader_program);
        glUseProgram(shader_program);
        vpMatLocation = glGetUniformLocation(shader_program, "viewProjMatrix");
        return;
    } // void initOpenGL()
    void renderObjects() {
        while (!glfwWindowShouldClose(window)) {
            glfwPollEvents();
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            int vbo = glGenBuffers();
            int ibo = glGenBuffers();
            float[] vertices = new float [Spot.MAX_ROWS * Spot.MAX_COLS * Spot.VPS * Spot.FPS];
            int[] indices = new int [Spot.MAX_ROWS * Spot.MAX_COLS * Spot.IPS];
            xmin = Spot.offsetHorizontal;
            xmax = xmin + Spot.length;
            ymax = 900 - Spot.offsetVertical;
            ymin = ymax - Spot.length;
            int index = 0;
            for (int row =0; row < Spot.MAX_ROWS; row++){
                for (int col = 0; col < Spot.MAX_COLS; col++){
                    vertices[index++] = xmin;
                    vertices[index++] = ymin;
                    vertices[index++] = xmax;
                    vertices[index++] = ymin;
                    vertices[index++] = xmax;
                    vertices[index++] = ymax;
                    vertices[index++] = xmin;
                    vertices[index++] = ymax;
                    xmin = xmax + Spot.padding;
                    xmax = xmin + Spot.length;
                }
                xmin = Spot.offsetHorizontal;
                xmax = xmin + Spot.length;
                ymax = ymin - Spot.padding;
                ymin = ymax - Spot.length;
            }
            int v_indx = 0;
            int my_i = 0;
            while (my_i < indices.length){
                indices[my_i++]= v_indx;
                indices[my_i++]= v_indx+1;
                indices[my_i++]= v_indx+2;
                indices[my_i++]= v_indx;
                indices[my_i++]= v_indx+2;
                indices[my_i++]= v_indx+3;
                v_indx += Spot.VPS;
            }
            glBindBuffer(GL_ARRAY_BUFFER, vbo);
            glBufferData(GL_ARRAY_BUFFER, (FloatBuffer) BufferUtils.
                    createFloatBuffer(vertices.length).
                    put(vertices).flip(), GL_STATIC_DRAW);
            glEnableClientState(GL_VERTEX_ARRAY);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
            glBufferData(GL_ELEMENT_ARRAY_BUFFER, (IntBuffer) BufferUtils.
                    createIntBuffer(indices.length).
                    put(indices).flip(), GL_STATIC_DRAW);
            glVertexPointer(2, GL_FLOAT, 0, 0L);
            //viewProjMatrix.setOrtho(0, 200, 0, 200, 0, 10);
            slCamera my_cam = new slCamera();
            my_cam.setProjectionOrtho(0, 900, 0, 1080, 0 ,5);
            viewProjMatrix = my_cam.getProjectionMatrix();
            glUniformMatrix4fv(vpMatLocation, false,
                    viewProjMatrix.get(myFloatBuffer));
            glUniform3f(renderColorLocation, 1.0f, 0.498f, 0.153f);
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
            int VTD = 4320; // need to process 6 Vertices To Draw 2 triangles * 360, the number of triangles
            glDrawElements(GL_TRIANGLES, VTD, GL_UNSIGNED_INT, 0L);
            glfwSwapBuffers(window);
        }
    } // renderObjects
}

